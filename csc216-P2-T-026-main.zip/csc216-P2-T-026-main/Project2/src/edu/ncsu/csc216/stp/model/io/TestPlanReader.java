/**
 * 
 */
package edu.ncsu.csc216.stp.model.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.tests.TestCase;
import edu.ncsu.csc216.stp.model.util.ISortedList;
import edu.ncsu.csc216.stp.model.util.SortedList;

/**
 * TestPlanReader Class
 */
public class TestPlanReader {
	/**
	 * Constructs a TestPlanReader
	 */
	public TestPlanReader() {
		//Empty
	}
	
	/**
	 * Reads TestPlans and TestCases from a file and imports them
	 * @param file the file to read from
	 * @throws IllegalArgumentException if unable to read from file
	 * @return a Sorted List of TestPlans read from the file
	 */
	public static ISortedList<TestPlan> readTestPlansFile(File file){
		try {
		Scanner fileReader = new Scanner(file);
		ISortedList<TestPlan> list = new SortedList<TestPlan>();
		
		String fileString = "";
		while (fileReader.hasNextLine()) {
			fileString += fileReader.nextLine() + "\n";
		}
		fileReader.close();
		//System.out.println(fileString);
		
		
		if (fileString.charAt(0) != '!') {
			throw new IllegalArgumentException("Unable to load file.");
		}
		
		String[] testPlanString = fileString.split("\\r?\\n?[!]");
		
		for (int i = 1; i < testPlanString.length; i++) {
			String[] testCaseString = testPlanString[i].split("\\r?\\n?[#]");
			
			TestPlan newTestPlan = new TestPlan(testCaseString[0].trim());
			
			for (int j = 1; j < testCaseString.length; j++) {
				String[] testResultString = testCaseString[j].split("\\r?\\\n?[-]");
				try {
					String[] testDescriptionExpectedString = testResultString[0].split("\\r?\\n?[*]");
					if (testDescriptionExpectedString.length != 3) {
						throw new Exception();
					}
					String[] testNameTypeString = testDescriptionExpectedString[0].split(",");
					TestCase newTestCase = new TestCase(testNameTypeString[0].trim(), testNameTypeString[1].trim(), testDescriptionExpectedString[1].trim(), testDescriptionExpectedString[2].trim());
					if (testResultString.length > 1) {
						for (int k = 1; k < testResultString.length; k++) {
							boolean passing;
							String[] testResultSplit = testResultString[k].split(":");
							if (testResultSplit[0].trim().equals("PASS")) {
								passing = true;
							} else {
								passing = false;
							}
							newTestCase.addTestResult(passing, testResultSplit[1].trim());
						}
					}
					newTestPlan.addTestCase(newTestCase);
				} catch (Exception e) {
					//do nothing
				}
			}
			list.add(newTestPlan);
		}
		return list;
		} catch (FileNotFoundException e) {
			throw new IllegalArgumentException("Unable to load file.");
		}
	}
	

}
