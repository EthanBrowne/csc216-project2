/**
 * 
 */
package edu.ncsu.csc216.stp.model.util;

/**
 * The Log Class
 * Extends ILog interface
 * @param <E> the Type of the list
 */
public class Log<E> implements ILog<E> {
	/** The list of Objects */
	private E[] log;
	/** The size of the list */
	private int size;
	/** Constant that represents the initial capacity of the list */
	private static final int INIT_CAPACITY = 10;
	
	/**
	 * Creates the list of type E
	 * Suppresses unchecked warning
	 */
	@SuppressWarnings("unchecked")
	public Log() {
		log = (E[]) new Object[INIT_CAPACITY];
		size = 0;
	}
	
	@Override
	public void add(E element) {
		if (element == null) {
			throw new NullPointerException("Cannot add null element.");
		} else if (log.length == size()) {
			growArray();
		}
		log[size] = element;
		size++;
	}

	@Override
	public E get(int idx) {
		if (idx >= size || idx < 0) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}
		return log[idx];
	}

	@Override
	public int size() {
		return size;
	}
	
	/**
	 * Helper method to increase the list capacity by 2.
	 */
	@SuppressWarnings("unchecked")
	private void growArray() {
		int newCapacity = log.length * 2;
		E[] newList = (E[]) new Object[newCapacity];
		
		for (int i = 0; i < size; i++) {
			newList[i] = log[i];
		}
		
		log = newList;
	}
}
