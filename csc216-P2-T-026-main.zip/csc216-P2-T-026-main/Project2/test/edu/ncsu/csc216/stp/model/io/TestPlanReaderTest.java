package edu.ncsu.csc216.stp.model.io;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.stp.model.test_plans.TestPlan;
import edu.ncsu.csc216.stp.model.util.ISortedList;

class TestPlanReaderTest {

	@Test
	void test() {
		ISortedList<TestPlan> t = TestPlanReader.readTestPlansFile(new File("test-files/test-plans1.txt"));
		assertEquals(t.get(0).getTestPlanName(), "PackScheduler");
	}

}
